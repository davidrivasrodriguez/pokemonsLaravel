<?php $__env->startSection('title', 'product list'); ?>

<?php $__env->startSection('basecontent'); ?>

    <table class="table table-striped table-hover" id="tablaProducto">
        <thead>
            <tr>
                <th>id</th>
                <th>name</th>
                <th>price</th>
                <?php if(session('user')): ?>
                    <th>delete</th>
                    <th>edit</th>
                <?php endif; ?>
                <th>view</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($product->id); ?></td>
                    <td><?php echo e($product->name); ?></td>
                    <td><?php echo e($product->price); ?></td>
                    <?php if(session('user')): ?>
                        <td><a href="#" data-href="<?php echo e(url('product/' . $product->id)); ?>" class = "borrar">delete</a></td>
                        <td><a href="<?php echo e(url('product/' . $product->id . '/edit')); ?>">edit</a></td>
                    <?php endif; ?>
                    <td><a href="<?php echo e(url('product/' . $product->id)); ?>">view</a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <div class="row">
        <?php if(session('user')): ?>
            <a href="<?php echo e(url('product/create')); ?>" class="btn btn-success">add product</a>
            <form id="formDelete" action="<?php echo e(url('')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('delete'); ?>
            </form>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(url('assets/scripts/script.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('product.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/pokemonsLaravel/resources/views/product/index.blade.php ENDPATH**/ ?>