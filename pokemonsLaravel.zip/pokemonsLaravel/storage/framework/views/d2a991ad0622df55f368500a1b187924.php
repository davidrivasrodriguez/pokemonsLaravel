<!doctype html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>dwes</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    </head>
    <body>
        <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
            <a class="navbar-brand" href="<?php echo e(url('')); ?>">dwes</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item <?php echo e($lihome ?? ''); ?>">
                        <a class="nav-link" href="<?php echo e(url('')); ?>">home</a>
                    </li>
                    <li class="nav-item <?php echo e($liproduct ?? ''); ?>">
                        <a class="nav-link" href="<?php echo e(url('product')); ?>">product</a>
                    </li>
                    <li class="nav-item <?php echo e($lifurniture ?? ''); ?>">
                        <a class="nav-link" href="<?php echo e(url('furniture')); ?>">furniture</a>
                    </li>
                    <li class="nav-item <?php echo e($lipokemon ?? ''); ?>">
                        <a class="nav-link" href="<?php echo e(url('pokemon')); ?>">pokemon</a>
                    </li>
                </ul>
            </div>
        </nav>
        <main role="main">
            <div class="jumbotron">
                <div class="container">
                    <h4 class="display-4"><?php echo $__env->yieldContent('maintitle', 'main'); ?></h4>
                </div>
            </div>
            <div class="container">
                <!-- para mostrar el mensaje de éxito -->
                <?php if(session('message')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('message')); ?>

                    </div>
                <?php endif; ?>

                <!-- para mostrar el mensaje de error -->
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger" role="alert">
                        <?php echo e($errors->first()); ?>

                    </div>
                <?php endif; ?>

                <div class="row">
                    <h3><?php echo $__env->yieldContent('title', 'products'); ?></h3>
                </div>

                <div>
                    <?php echo $__env->yieldContent('content'); ?>
                </div>

                <hr>
            </div>
        </main>
        <footer class="container">
            <p>&copy; IZV 2024</p>
        </footer>
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
        <?php echo $__env->yieldContent('scripts'); ?>
    </body>
</html><?php /**PATH /var/www/html/laraveles/pokemonsLaravel/resources/views/base.blade.php ENDPATH**/ ?>