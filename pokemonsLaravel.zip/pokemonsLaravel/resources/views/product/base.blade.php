@extends('base')

@section('maintitle', 'products')

@section('title', '')

@section('content')

    @yield('basecontent')
    <hr>

@endsection