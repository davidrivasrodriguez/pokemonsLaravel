<?php $__env->startSection('title', 'products, etc.'); ?>

<?php $__env->startSection('content'); ?>

    <?php if(session('user')): ?>
        <a href="<?php echo e(url('logout')); ?>" class="btn btn-success">log out</a>
    <?php else: ?>
        <a href="<?php echo e(url('login')); ?>" class="btn btn-success">log in</a>
    <?php endif; ?>
    &nbsp;
    <a href="<?php echo e(url('product')); ?>" class="btn btn-success">products</a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/pokemonsLaravel/resources/views/main/main.blade.php ENDPATH**/ ?>