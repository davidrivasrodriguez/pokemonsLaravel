<?php $__env->startSection('maintitle', 'products'); ?>

<?php $__env->startSection('title', ''); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->yieldContent('basecontent'); ?>
    <hr>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/pokemonsLaravel/resources/views/product/base.blade.php ENDPATH**/ ?>