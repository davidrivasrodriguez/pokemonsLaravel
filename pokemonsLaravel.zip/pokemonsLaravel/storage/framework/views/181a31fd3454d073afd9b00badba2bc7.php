<?php $__env->startSection('title', 'Editar Pokémon'); ?>
<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(url('pokemon/' . $pokemon->id)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>
        <div class="form-group">
            <label for="name">Nombre del Pokémon</label>
            <input value="<?php echo e(old('name', $pokemon->name)); ?>" required type="text" class="form-control" id="name" name="name" placeholder="Nombre del Pokémon">
        </div>
        <div class="form-group">
            <label for="weight">Peso del Pokémon</label>
            <input value="<?php echo e(old('weight', $pokemon->weight)); ?>" required type="number" step="0.01" class="form-control" id="weight" name="weight" placeholder="Peso del Pokémon">
        </div>
        <div class="form-group">
            <label for="height">Altura del Pokémon</label>
            <input value="<?php echo e(old('height', $pokemon->height)); ?>" required type="number" step="0.01" class="form-control" id="height" name="height" placeholder="Altura del Pokémon">
        </div>
        <div class="form-group">
            <label for="type_id">Tipo del Pokémon</label>
            <select required class="form-control" id="type_id" name="type_id">
                <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($type->id); ?>" <?php echo e(old('type_id', $pokemon->type_id) == $type->id ? 'selected' : ''); ?>><?php echo e($type->type); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group">
            <label for="evolution_count">Evoluciones</label>
            <input value="<?php echo e(old('evolution_count', $pokemon->evolution_count)); ?>" required type="number" min="0" class="form-control" id="evolution_count" name="evolution_count" placeholder="Evoluciones">
        </div>
        <button type="submit" class="btn btn-primary">Editar</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/pokemonsLaravel/resources/views/pokemon/edit.blade.php ENDPATH**/ ?>