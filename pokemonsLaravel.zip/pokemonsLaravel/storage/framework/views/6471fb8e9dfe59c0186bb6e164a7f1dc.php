<?php $__env->startSection('title', 'Lista de Pokémon'); ?>
<?php $__env->startSection('content'); ?>
    <table class="table table-striped table-hover" id="tablaPokemon">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Peso</th>
                <th>Altura</th>
                <th>Tipo</th>
                <th>Evoluciones</th>
                <?php if(session('user')): ?>
                    <th>Eliminar</th>
                    <th>Editar</th>
                <?php endif; ?>
                <th>Ver</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $pokemon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poke): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($poke->id); ?></td>
                    <td><?php echo e($poke->name); ?></td>
                    <td><?php echo e($poke->weight); ?> kg</td>
                    <td><?php echo e($poke->height); ?> m</td>
                    <td><?php echo e($poke->type->type); ?></td>
                    <td><?php echo e($poke->evolution_count); ?></td>
                    <?php if(session('user')): ?>
                        <td><a href="#" data-href="<?php echo e(url('pokemon/' . $poke->id)); ?>" class="borrar">Eliminar</a></td>
                        <td><a href="<?php echo e(url('pokemon/' . $poke->id . '/edit')); ?>">Editar</a></td>
                    <?php endif; ?>
                    <td><a href="<?php echo e(url('pokemon/' . $poke->id)); ?>">Ver</a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <div class="row">
        <?php if(session('user')): ?>
            <a href="<?php echo e(url('pokemon/create')); ?>" class="btn btn-success">Añadir Pokémon</a>
            <form id="formDelete" action="<?php echo e(url('')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('delete'); ?>
            </form>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(url('assets/scripts/script.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/pokemonsLaravel/resources/views/pokemon/index.blade.php ENDPATH**/ ?>