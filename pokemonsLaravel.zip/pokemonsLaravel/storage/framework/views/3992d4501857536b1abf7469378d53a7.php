<?php $__env->startSection('title', 'furniture list'); ?>

<?php $__env->startSection('content'); ?>

    <table class="table table-striped table-hover" id="tablaMueble">
        <thead>
            <tr>
                <th>id</th>
                <th>model</th>
                <th>price</th>
                <?php if(session('user')): ?>
                    <th>delete</th>
                    <th>edit</th>
                <?php endif; ?>
                <th>view</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $furnitures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $furniture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($furniture->id); ?></td>
                    <td><?php echo e($furniture->model); ?></td>
                    <td><?php echo e($furniture->price); ?></td>
                    <?php if(session('user')): ?>
                        <td><a href="#" data-href="<?php echo e(url('furniture/' . $furniture->id)); ?>" class = "borrar">delete</a></td>
                        <td><a href="<?php echo e(url('furniture/' . $furniture->id . '/edit')); ?>">edit</a></td>
                    <?php endif; ?>
                    <td><a href="<?php echo e(url('furniture/' . $furniture->id)); ?>">view</a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <div class="row">
        <?php if(session('user')): ?>
            <a href="<?php echo e(url('furniture/create')); ?>" class="btn btn-success">add furniture</a>
            <form id="formDelete" action="<?php echo e(url('')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('delete'); ?>
            </form>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(url('assets/scripts/script.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/pokemonsLaravel/resources/views/furniture/index.blade.php ENDPATH**/ ?>