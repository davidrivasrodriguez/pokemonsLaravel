<?php $__env->startSection('title', 'Detalles del Pokémon'); ?>
<?php $__env->startSection('content'); ?>
    <div class="form-group">
        Pokémon número #:
        <?php echo e($pokemon->id); ?>

    </div>
    <div class="form-group">
        Nombre del Pokémon:
        <?php echo e($pokemon->name); ?>

    </div>
    <div class="form-group">
        Peso del Pokémon:
        <?php echo e($pokemon->weight); ?> kg
    </div>
    <div class="form-group">
        Altura del Pokémon:
        <?php echo e($pokemon->height); ?> m
    </div>
    <div class="form-group">
        Tipo del Pokémon:
        <?php echo e($pokemon->type->type); ?>

    </div>
    <div class="form-group">
        Evoluciones:
        <?php echo e($pokemon->evolution_count); ?>

    </div>
    <div class="form-group">
        <a href="<?php echo e(url()->previous()); ?>">Volver</a>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/pokemonsLaravel/resources/views/pokemon/show.blade.php ENDPATH**/ ?>